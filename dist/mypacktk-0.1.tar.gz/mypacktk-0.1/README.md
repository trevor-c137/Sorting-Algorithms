#PACKAGE-NAME-mypacktk
mypacktk which uses some recursion functions and sorting functions

## recursion

1.sum_array(array)- Is A function calculates sum  of all items in array

2.fibonacci(n): sum_array(array)- Return nth term in fibonacci sequence

3.factorial(n): this function returns the factorial of n

4. reverse(word): Return word in reverse

## sorting

1.bubble_sort(items)-Return array of items, sorted in ascending order
2.merge_sort(items) Return array of items, sorted in ascending order b
3.quick_sort(items): Return array of items, sorted in ascending order


## Installation

## building a python package
' python setup.py sdist '

## installing this package from github
'pip install package+https://github.com/K1TS/mypackage.git   '

## updating this package from github
'pip install --upgrade git +https://github.com/K1TS/mypackage.git'
